# Suggesting Social Media Posts

Node.js social media is managed by OpenJS Foundation staff. The processes are
documented in
[Node.js Social Amplification Request Guidelines](https://docs.google.com/document/d/1yrYZJ2twrbpUuScbo3rmN_v-Jfv6d2tO74nCT6PcpxI).
