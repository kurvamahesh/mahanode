# Policies

<!--introduced_in=v11.8.0-->

<!-- type=misc -->

> Stability: 1 - Experimental

The former Policies documentation is now at [Permissions documentation][]

[Permissions documentation]: permissions.md#policies
