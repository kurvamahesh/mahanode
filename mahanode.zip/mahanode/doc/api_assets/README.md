# API Reference Document Assets

## api.js

The main script for API reference documents.

## hljs.css

The syntax theme for code snippets in API reference documents.

## style.css

The main stylesheet for API reference documents.
